"""Contains shared configuration settings for the thermostat application."""

DEBUG = True